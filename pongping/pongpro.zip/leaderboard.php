<?php
// leaderboard.php
require_once __DIR__ . '/config.php';

try {
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    if ($limit <= 0) $limit = 10;

    // Order by player_score desc, then by (player_score - ai_score) desc for tiebreaker, then earliest date
    $sql = "SELECT u.username, s.player_score, s.ai_score, s.difficulty, s.winner, s.created_at,
                   (s.player_score - s.ai_score) AS score_diff
            FROM scores s
            JOIN users u ON s.user_id = u.id
            ORDER BY s.player_score DESC, score_diff DESC, s.created_at ASC
            LIMIT :lim";

    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll();
    echo json_encode($rows);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
